package com.ibm.magentopages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ForgotPaswrd {
	
	
	@FindBy(linkText="Forgot Your Password?")
	WebElement ForgetButn;
	

	@FindBy(xpath="//button[@type='submit']")
	WebElement SubmitBtn;
	
	@FindBy(xpath="//input[@id='email_address']")
	WebElement emailaddress;
	
	By errorMsg =By.className("validation-advice");
	
    By errorMsg1= By.id("advice-validate-email-email_address");
    
	WebDriverWait wait;
	WebDriver driver;
	
	public ForgotPaswrd(WebDriver driver,WebDriverWait wait) {
		PageFactory.initElements(driver, this);
		this.driver=driver;
		this.wait=wait;
	}

	public void enteremailAddress(String userName1)
	{
		emailaddress.sendKeys(userName1);
	}
	
	public void clickOnForgetyourPasswrd()
	{
		ForgetButn.click();
	}
	
	public void clickOnSubmitButton()
	{
		SubmitBtn.click();
	}
	
	public String getPageSourceForInvalidErrorMessage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(errorMsg));
		
		return driver.getPageSource();
	}
	public String getPageSourceForInvalidErrorMessage1()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(errorMsg1));
		
		return driver.getPageSource();
	}
}



