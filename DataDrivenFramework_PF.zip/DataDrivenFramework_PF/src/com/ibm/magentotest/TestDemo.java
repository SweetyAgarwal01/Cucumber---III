package com.ibm.magentotest;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class TestDemo  {
	
	
	//balajidinakaran@gmail.com, Welcome123
	//balaji0017@gmail.com, Welcome123
	@DataProvider(name="credentials",parallel=true)
	public Object[][] credentials()
	{
		//i -- no of times run the testcase
		//j-->no of parameters
		
		Object[][] temp =new Object[3][2];   
		
		temp[0][0]="balajidinakaran@gmail.com";
		temp[0][1]="Welcome123";
		
		temp[1][0]="balaji0017@gmail.com";
		temp[1][1]="Welcome123";	
		
		temp[2][0]="balaji0017@gmail.com";
		temp[2][1]="Welcome123";	
		return temp;
	}

	
	
	
	
	@Test(dataProvider="credentials")
	public void loginCheck(String userName,String password)
	{
		System.out.println(userName);
		System.out.println(password);
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver =  new ChromeDriver();
		driver.get("http:\\google.com");
		
	   WebElement searchEle=	driver.findElement(By.name("q"));
		searchEle.sendKeys(userName+password);
		
		
	}
	
	
	/*@BeforeMethod
	@Parameters({"browser"})
	public void test1(@Optional("ch") String browser)
	{
		System.out.println(browser);
	}
	@Test
	public void test2()
	{
		System.out.println("Test 2");
	}*/

	/*@Test
	public void test3()
	{
		System.out.println("Test 3");
	}*/
	/*@BeforeTest
	public void bTest()
	{
		System.out.println("Before Test");
	}
	
	@AfterTest
	public void aTest()
	{
		System.out.println("After Test");
	}
	
	
	@BeforeSuite
	public void bSuite()
	{
		System.out.println("Before Suite");
	}
	
	@AfterSuite
	public void aSuite()
	{
		System.out.println("After Suite");
	}
	
	
	@BeforeMethod
	public void bMethod()
	{
		System.out.println("bMethod");
	}
	
	@AfterMethod
	public void aMethod()
	{
		System.out.println("aMethod");
	}*/
	
/*	@Test
	public void test1()
	{
		System.out.println("Test 1");
	}
	
	@Test
	public void test2()
	{
		System.out.println("Test 2");
	}

	@Test
	public void test3()
	{
		System.out.println("Test 3");
	}
	@Test
	public void baseTest1()
	{
		System.out.println("baseTest1");
	}
	
	@Test
	public void baseTest2()
	{
		System.out.println("baseTest2dddd");
		Assert.fail();
		
	}

	@Test
	public void baseTest3()
	{
		System.out.println("baseTest3");
	}*/
}
